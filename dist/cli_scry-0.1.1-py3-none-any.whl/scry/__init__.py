"""scry: Peer into any Python codebase."""

__version__ = "0.1.0"

from scry.cli import main

__all__ = ["main"]